# db_config = {'user': '****',
#              'password':'****',
#              'host':'******',
#              'database': '****'}

# s3_bucketname = '*******'

# aws_connect_args = {
#     'aws_access_key_id':'*******',
#     'aws_secret_access_key':'****************',
#     'region_name':'**********'
# }
